for filename in RMQ*.ini; do
        echo $filename
        sed -i -e 's/10.0.129.227/10.0.143.126/g' ${filename##*/}
done
for filename in RabbitMQ*.ini; do
        echo $filename
        sed -i -e 's/10.0.129.227/10.0.143.126/g' ${filename##*/}
done

