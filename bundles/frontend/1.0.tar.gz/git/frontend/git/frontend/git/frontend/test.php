<?php
$username = $_POST["user"];
echo $username;
?>
